# -*- coding: utf-8 -*-
"""生成 SaaS 用户行为模拟数据集 (users.csv / events.csv)"""
import csv, random, datetime as dt
from pathlib import Path

random.seed(20260917)
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

SIGNUP_START = dt.date(2026, 1, 1)
SIGNUP_END   = dt.date(2026, 7, 31)   # 注册窗口
DATA_END     = dt.date(2026, 8, 31)   # 行为数据截止

CHANNELS = [("自然流量", .30), ("SEM投放", .27), ("内容营销", .22), ("老客推荐", .13), ("线下活动", .08)]
# 各渠道的漏斗通过率（登录, 创建项目, 邀请协作者, 生成首份报表）
LEAK = {
    "自然流量": (0.93, 0.58, 0.80, 0.87),
    "SEM投放":  (0.90, 0.55, 0.78, 0.86),
    "内容营销": (0.96, 0.70, 0.82, 0.90),
    "老客推荐": (0.98, 0.82, 0.88, 0.93),
    "线下活动": (0.95, 0.74, 0.84, 0.90),
}
PLANS = [("免费版", .55), ("试用版", .30), ("专业版", .15)]

N_USERS = 5000
users, events = [], []
eid = 0

def ev(uid, when, name):
    global eid
    eid += 1
    events.append((eid, uid, when.strftime("%Y-%m-%d %H:%M:%S"), name))

def rand_dt(day, hmin=9, hmax=22):
    return dt.datetime.combine(day, dt.time(random.randint(hmin, hmax), random.randint(0, 59), random.randint(0, 59)))

def month_add(d, n):
    m = d.month - 1 + n
    y = d.year + m // 12
    return dt.date(y, m % 12 + 1, 1)

for uid in range(1, N_USERS + 1):
    signup = SIGNUP_START + dt.timedelta(days=random.randint(0, (SIGNUP_END - SIGNUP_START).days))
    ch = random.choices([c for c, _ in CHANNELS], weights=[w for _, w in CHANNELS])[0]
    plan = random.choices([p for p, _ in PLANS], weights=[w for _, w in PLANS])[0]
    users.append((uid, signup.strftime("%Y-%m-%d"), ch, plan))

    # 漏斗：注册(埋点即注册成功)
    ev(uid, rand_dt(signup, 0, 23), "signup")
    t = signup
    p_login, p_project, p_invite, p_report = LEAK[ch]
    # 首日登录
    if random.random() < p_login:
        login_day = t + dt.timedelta(days=random.choices([0, 1, 2, 3], weights=[.75, .15, .07, .03])[0])
        ev(uid, rand_dt(login_day), "login")
        cur = login_day
        # 创建首个项目
        if random.random() < p_project:
            cur = cur + dt.timedelta(days=random.choices([0, 1, 2, 3, 5], weights=[.55, .2, .12, .08, .05])[0])
            ev(uid, rand_dt(cur), "create_project")
            # 邀请协作者
            if random.random() < p_invite:
                cur = cur + dt.timedelta(days=random.choices([0, 1, 2, 4], weights=[.5, .25, .15, .1])[0])
                ev(uid, rand_dt(cur), "invite_member")
                # 生成首份分析报表（激活完成，aha 时刻）
                if random.random() < p_report:
                    cur = cur + dt.timedelta(days=random.choices([0, 1, 2, 3], weights=[.6, .22, .12, .06])[0])
                    ev(uid, rand_dt(cur), "generate_report")
                    activated = True
                else:
                    activated = False
            else:
                activated = False
        else:
            activated = False
    else:
        activated = False

    # 激活后的持续活跃（月度会话），未激活用户低频回访
    m = 1
    alive = True
    while alive:
        mstart = month_add(signup, m)
        if mstart > DATA_END:
            break
        if activated:
            # 按月递减的活跃概率，专业版留存更好
            base = 0.80 if plan == "专业版" else (0.62 if plan == "试用版" else 0.52)
            p_active = max(0.18, base - 0.07 * (m - 1))
        else:
            p_active = max(0.06, 0.24 - 0.05 * (m - 1))
        if random.random() > p_active:
            alive = False  # 当月未活跃 → 之后大概率流失（少量随机回归）
            if random.random() < 0.08:
                m += 1
                continue
            break
        # 当月有若干次会话
        days_in_month = (month_add(signup, m + 1) - mstart).days
        last_day = min(DATA_END, month_add(signup, m + 1) - dt.timedelta(days=1))
        for _ in range(random.randint(2, 6)):
            d = mstart + dt.timedelta(days=random.randint(0, (last_day - mstart).days))
            ev(uid, rand_dt(d), "login")
            if activated and random.random() < 0.7:
                ev(uid, rand_dt(d), "generate_report")
            if random.random() < 0.5:
                ev(uid, rand_dt(d), "dashboard_view")
            if activated and random.random() < 0.35:
                ev(uid, rand_dt(d), "export_data")
            if activated and random.random() < 0.15:
                ev(uid, rand_dt(d), "invite_member")
        m += 1

with open(DATA / "users.csv", "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["user_id", "signup_date", "channel", "plan"])
    w.writerows(users)

with open(DATA / "events.csv", "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["event_id", "user_id", "event_time", "event_name"])
    w.writerows(sorted(events, key=lambda r: r[2]))

print(f"users={len(users)}, events={len(events)}")
