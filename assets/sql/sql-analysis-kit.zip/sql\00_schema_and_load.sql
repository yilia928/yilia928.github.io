-- =============================================================
-- 00_schema_and_load.sql
-- 建表并加载 CSV 数据（SQLite，命令行执行方式见文件底部注释）
-- =============================================================
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS events;

CREATE TABLE users (
    user_id     INTEGER PRIMARY KEY,
    signup_date TEXT NOT NULL,          -- 注册日期 YYYY-MM-DD
    channel     TEXT NOT NULL,          -- 获客渠道
    plan        TEXT NOT NULL           -- 套餐：免费版/试用版/专业版
);

CREATE TABLE events (
    event_id   INTEGER PRIMARY KEY,
    user_id    INTEGER NOT NULL,
    event_time TEXT NOT NULL,          -- 事件时间 YYYY-MM-DD HH:MM:SS
    event_name TEXT NOT NULL           -- 事件名
);

CREATE INDEX idx_events_user  ON events(user_id, event_time);
CREATE INDEX idx_events_name  ON events(event_name);
CREATE INDEX idx_users_signup ON users(signup_date);

-- 命令行加载方式（在 sql/ 目录下执行 sqlite3 saas.db 后）：
--   .mode csv
--   .import ../data/users.csv  users
--   .import ../data/events.csv events
-- 注意：CSV 含 BOM 表头时，可先 load 后用 UPDATE 修正列名，或用去 BOM 的 CSV。
