-- =============================================================
-- 01_activation_funnel.sql
-- 新用户激活漏斗：
--   注册 → 首次登录 → 创建首个项目 → 邀请协作者 → 生成首份分析报表(激活)
-- 口径：严格按漏斗顺序，后一步事件时间必须晚于前一步首次完成时间
-- 输出：每步人数 / 整体转化率 / 相邻步转化率 / 步间流失率
-- =============================================================
WITH first_events AS (
    SELECT u.user_id,
           u.channel,
           u.signup_date,
           MIN(CASE WHEN e.event_name = 'signup'          THEN e.event_time END) AS t_signup,
           MIN(CASE WHEN e.event_name = 'login'           THEN e.event_time END) AS t_login,
           MIN(CASE WHEN e.event_name = 'create_project'  THEN e.event_time END) AS t_project,
           MIN(CASE WHEN e.event_name = 'invite_member'   THEN e.event_time END) AS t_invite,
           MIN(CASE WHEN e.event_name = 'generate_report' THEN e.event_time END) AS t_report
    FROM users u
    LEFT JOIN events e ON e.user_id = u.user_id
    GROUP BY u.user_id
),
ordered AS (  -- 只保留按漏斗顺序完成的事件序列
    SELECT *,
           CASE WHEN t_login   IS NOT NULL AND (t_signup  IS NULL OR date(t_login)   >= date(t_signup))  THEN 1 ELSE 0 END AS s_login,
           CASE WHEN t_project IS NOT NULL AND (t_login   IS NULL OR date(t_project) >= date(t_login))   THEN 1 ELSE 0 END AS s_project,
           CASE WHEN t_invite  IS NOT NULL AND (t_project IS NULL OR date(t_invite)  >= date(t_project)) THEN 1 ELSE 0 END AS s_invite,
           CASE WHEN t_report  IS NOT NULL AND (t_invite  IS NULL OR date(t_report)  >= date(t_invite))  THEN 1 ELSE 0 END AS s_report
    FROM first_events
)
SELECT '注册'                        AS step, COUNT(*) AS users, 100.0 AS overall_pct, NULL AS step_pct, NULL AS drop_pct FROM ordered
UNION ALL
SELECT '首次登录',                   SUM(s_login),   ROUND(100.0*SUM(s_login)/COUNT(*),2),          NULL, NULL FROM ordered
UNION ALL
SELECT '创建首个项目',               SUM(s_project), ROUND(100.0*SUM(s_project)/COUNT(*),2), NULL, NULL FROM ordered
UNION ALL
SELECT '邀请协作者',                 SUM(s_invite),  ROUND(100.0*SUM(s_invite)/COUNT(*),2),  NULL, NULL FROM ordered
UNION ALL
SELECT '生成首份报表(激活完成)',     SUM(s_report),  ROUND(100.0*SUM(s_report)/COUNT(*),2),  NULL, NULL FROM ordered;
