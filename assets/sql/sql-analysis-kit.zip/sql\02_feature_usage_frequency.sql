-- =============================================================
-- 02_feature_usage_frequency.sql
-- 核心功能使用频次分析
-- 输出1：各功能的使用总量 / 使用人数 / 人均使用次数
-- 输出2：激活用户 vs 未激活用户的人均功能使用对比
-- 输出3：月度报表生成频次分布（活跃深度）
-- =============================================================
-- ① 各功能使用总量与人均频次
SELECT e.event_name                                  AS feature,
       COUNT(*)                                      AS total_uses,
       COUNT(DISTINCT e.user_id)                     AS active_users,
       ROUND(1.0*COUNT(*)/COUNT(DISTINCT e.user_id),2) AS avg_uses_per_user
FROM events e
GROUP BY e.event_name
ORDER BY total_uses DESC;

-- ② 激活(生成过报表)与未激活用户的人均使用对比
WITH activated AS (
    SELECT DISTINCT user_id FROM events WHERE event_name = 'generate_report'
)
SELECT CASE WHEN a.user_id IS NOT NULL THEN '已激活用户' ELSE '未激活用户' END AS user_group,
       COUNT(*)                                          AS total_uses,
       COUNT(DISTINCT e.user_id)                         AS users,
       ROUND(1.0*COUNT(*)/COUNT(DISTINCT e.user_id),2)   AS avg_uses_per_user
FROM events e
LEFT JOIN activated a ON a.user_id = e.user_id
GROUP BY 1;

-- ③ 已激活用户：月人均报表生成次数（活跃深度）
WITH activated AS (
    SELECT DISTINCT user_id FROM events WHERE event_name = 'generate_report'
),
report_month AS (
    SELECT e.user_id,
           strftime('%Y-%m', e.event_time) AS ym,
           COUNT(*) AS cnt
    FROM events e
    JOIN activated a ON a.user_id = e.user_id
    WHERE e.event_name = 'generate_report'
    GROUP BY 1, 2
),
buckets AS (
    SELECT user_id, ym, cnt,
           CASE WHEN cnt = 1 THEN '1次'
                WHEN cnt <= 3 THEN '2-3次'
                WHEN cnt <= 6 THEN '4-6次'
                WHEN cnt <= 10 THEN '7-10次'
                ELSE '10次以上' END AS freq_bucket
    FROM report_month
)
SELECT freq_bucket       AS monthly_report_freq,
       COUNT(*)          AS user_months,
       ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM report_month),2) AS pct
FROM buckets
GROUP BY freq_bucket
ORDER BY MIN(cnt);
