-- =============================================================
-- 04_funnel_leak_locator.sql
-- 漏斗流失定位：分渠道 × 分套餐的相邻步转化率
-- 用于找出流失最严重的环节与人群
-- =============================================================
WITH first_events AS (
    SELECT u.user_id, u.channel, u.plan,
           MIN(CASE WHEN e.event_name='signup'          THEN e.event_time END) AS t_signup,
           MIN(CASE WHEN e.event_name='login'           THEN e.event_time END) AS t_login,
           MIN(CASE WHEN e.event_name='create_project'  THEN e.event_time END) AS t_project,
           MIN(CASE WHEN e.event_name='invite_member'   THEN e.event_time END) AS t_invite,
           MIN(CASE WHEN e.event_name='generate_report' THEN e.event_time END) AS t_report
    FROM users u
    LEFT JOIN events e ON e.user_id = u.user_id
    GROUP BY u.user_id
),
steps AS (
    SELECT channel, plan,
           COUNT(*)                                   AS n_signup,
           SUM(CASE WHEN date(t_login)   >= date(t_signup)  THEN 1 ELSE 0 END) AS n_login,
           SUM(CASE WHEN date(t_project) >= date(t_login)   THEN 1 ELSE 0 END) AS n_project,
           SUM(CASE WHEN date(t_invite)  >= date(t_project) THEN 1 ELSE 0 END) AS n_invite,
           SUM(CASE WHEN date(t_report)  >= date(t_invite)  THEN 1 ELSE 0 END) AS n_report
    FROM first_events
    GROUP BY channel, plan
)
SELECT channel, plan,
       n_signup,
       ROUND(100.0*n_login   / n_signup, 1) AS conv_login,
       ROUND(100.0*n_project / n_login,   1) AS conv_project,   -- ← 重点观察
       ROUND(100.0*n_invite  / n_project, 1) AS conv_invite,
       ROUND(100.0*n_report  / n_invite,  1) AS conv_report,
       ROUND(100.0*n_report  / n_signup,  1) AS conv_overall
FROM steps
ORDER BY conv_project ASC
LIMIT 10;
