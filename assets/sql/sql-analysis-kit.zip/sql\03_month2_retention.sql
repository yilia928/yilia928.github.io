-- =============================================================
-- 03_month2_retention.sql
-- 次月留存分析
-- 口径：注册月 M 的用户，在 M+1 自然月内至少有 1 次 login 行为
-- 输出1：按注册月(同期群 cohort)的次月留存
-- 输出2：按渠道的次月留存
-- 输出3：已激活 vs 未激活用户的次月留存对比
-- =============================================================
WITH user_cohort AS (
    SELECT u.user_id,
           u.channel,
           u.signup_date,
           substr(u.signup_date, 1, 7) AS cohort_month,
           strftime('%Y-%m', date(u.signup_date, '+1 month', 'start of month')) AS next_month,
           CASE WHEN EXISTS (SELECT 1 FROM events e2 WHERE e2.event_name='generate_report' AND e2.user_id=u.user_id)
                THEN 1 ELSE 0 END AS is_activated
    FROM users u
),
active_months AS (
    SELECT DISTINCT user_id, strftime('%Y-%m', event_time) AS active_month
    FROM events
    WHERE event_name = 'login'
)
-- ① 按注册月的次月留存
SELECT c.cohort_month                                   AS cohort,
       COUNT(*)                                         AS new_users,
       SUM(CASE WHEN am.user_id IS NOT NULL THEN 1 ELSE 0 END) AS retained_users,
       ROUND(100.0*SUM(CASE WHEN am.user_id IS NOT NULL THEN 1 ELSE 0 END)/COUNT(*),2) AS m2_retention_pct
FROM user_cohort c
LEFT JOIN active_months am
       ON am.user_id = c.user_id AND am.active_month = c.next_month
GROUP BY c.cohort_month
ORDER BY c.cohort_month;

-- ② 按渠道的次月留存
WITH user_cohort AS (
    SELECT u.user_id, u.channel,
           strftime('%Y-%m', date(u.signup_date, '+1 month', 'start of month')) AS next_month
    FROM users u
),
active_months AS (
    SELECT DISTINCT user_id, strftime('%Y-%m', event_time) AS active_month
    FROM events
    WHERE event_name = 'login'
)
SELECT c.channel                                        AS channel,
       COUNT(*)                                         AS new_users,
       SUM(CASE WHEN am.user_id IS NOT NULL THEN 1 ELSE 0 END) AS retained_users,
       ROUND(100.0*SUM(CASE WHEN am.user_id IS NOT NULL THEN 1 ELSE 0 END)/COUNT(*),2) AS m2_retention_pct
FROM user_cohort c
LEFT JOIN active_months am
       ON am.user_id = c.user_id AND am.active_month = c.next_month
GROUP BY c.channel
ORDER BY m2_retention_pct DESC;

-- ③ 已激活 vs 未激活的次月留存
WITH user_cohort AS (
    SELECT u.user_id,
           CASE WHEN EXISTS (SELECT 1 FROM events e2 WHERE e2.event_name='generate_report' AND e2.user_id=u.user_id)
                THEN 1 ELSE 0 END AS is_activated,
           strftime('%Y-%m', date(u.signup_date, '+1 month', 'start of month')) AS next_month
    FROM users u
),
active_months AS (
    SELECT DISTINCT user_id, strftime('%Y-%m', event_time) AS active_month
    FROM events
    WHERE event_name = 'login'
)
SELECT CASE WHEN c.is_activated = 1 THEN '已激活用户' ELSE '未激活用户' END AS user_group,
       COUNT(*)                                                          AS new_users,
       SUM(CASE WHEN am.user_id IS NOT NULL THEN 1 ELSE 0 END)           AS retained_users,
       ROUND(100.0*SUM(CASE WHEN am.user_id IS NOT NULL THEN 1 ELSE 0 END)/COUNT(*),2) AS m2_retention_pct
FROM user_cohort c
LEFT JOIN active_months am
       ON am.user_id = c.user_id AND am.active_month = c.next_month
GROUP BY 1;
