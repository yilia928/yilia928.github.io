# SaaS 产品功能使用与留存分析（SQL）

基于 SaaS 用户行为数据集，用 SQL 完成三类分析（激活漏斗 / 功能使用频次 / 次月留存），定位激活漏斗中流失最严重的环节，并给出数据驱动的产品改进建议。

## 目录结构

```
saas-retention-analysis/
├── data/
│   ├── users.csv            # 用户维表（5,000 用户：注册日期/渠道/套餐）
│   └── events.csv           # 行为事件表（46,549 条：signup/login/create_project/
│                            #   invite_member/generate_report/export_data/dashboard_view）
├── sql/
│   ├── 00_schema_and_load.sql   # 建表 + CSV 装载（SQLite）
│   ├── 01_activation_funnel.sql # 新用户激活漏斗
│   ├── 02_feature_usage_frequency.sql # 核心功能使用频次
│   ├── 03_month2_retention.sql  # 次月留存（同期群/渠道/激活对比）
│   └── 04_funnel_leak_locator.sql     # 漏斗流失定位（渠道×套餐）
├── scripts/
│   ├── generate_data.py     # 模拟数据集生成（可复现，seed 固定）
│   └── run_analysis.py      # 一键建库 + 执行全部 SQL + 导出 results.json
├── 分析报告.html            # 数据分析报告（含图表与改进建议）
├── 指标口径定义.md          # 指标口径定义文档
└── results.json             # SQL 运行结果原始输出
```

## 复现步骤

方式一（推荐，一键）：

```bash
python scripts/generate_data.py   # 重新生成数据（可选，data/ 下已含数据）
python scripts/run_analysis.py    # 建库 → 执行 01~04 → 输出 results.json 并打印结果
```

方式二（sqlite3 命令行）：

```bash
sqlite3 saas.db < sql/00_schema_and_load.sql
sqlite3 saas.db ".mode csv" ".import data/users.csv users" ".import data/events.csv events"
sqlite3 -header -column saas.db < sql/01_activation_funnel.sql
# 依次执行 02 / 03 / 04
```

## 核心结论速览

| 指标 | 数值 |
|---|---|
| 整体激活率（完成五步漏斗） | 43.7% |
| 流失最严重环节 | 首次登录 → 创建首个项目（步间转化 63.0%，单步流失 1,753 人） |
| 最薄弱人群 | SEM 投放渠道（创建项目转化 48.8%~54.1%，次月留存 33.0%） |
| 平均次月留存 | ~40%；激活用户 59.7% vs 未激活 23.7% |
| 使用深度 | 56.4% 的激活用户-月仅生成 1 份报表 |

> 说明：数据集为模拟生成（方法演示用）；接入真实数据时只需替换 `data/` 下两个 CSV，SQL 无需改动。
