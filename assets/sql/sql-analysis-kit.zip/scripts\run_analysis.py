# -*- coding: utf-8 -*-
"""加载 CSV 到 SQLite，执行 SQL 脚本，结果输出到 results.json"""
import csv, sqlite3, json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB = ROOT / "saas.db"
if DB.exists():
    DB.unlink()

con = sqlite3.connect(DB)
con.execute("""CREATE TABLE users (user_id INTEGER PRIMARY KEY, signup_date TEXT, channel TEXT, plan TEXT)""")
con.execute("""CREATE TABLE events (event_id INTEGER PRIMARY KEY, user_id INTEGER, event_time TEXT, event_name TEXT)""")

def rows(path):
    with open(path, encoding="utf-8-sig") as f:
        r = csv.reader(f)
        next(r)
        return list(r)

con.executemany("INSERT INTO users VALUES (?,?,?,?)", rows(ROOT/"data/users.csv"))
con.executemany("INSERT INTO events VALUES (?,?,?,?)", rows(ROOT/"data/events.csv"))
con.commit()

def split_queries(sql):
    sql = re.sub(r"--.*", "", sql)
    return [q.strip() for q in sql.split(";") if q.strip()]

out = {}
for f in sorted((ROOT/"sql").glob("0*.sql")):
    if f.name.startswith("00"):
        continue  # 00 为建表脚本，表结构已在上方创建
    qs = split_queries(f.read_text(encoding="utf-8"))
    blocks = []
    for q in qs:
        cur = con.execute(q)
        if cur.description is None:
            continue
        cols = [d[0] for d in cur.description]
        data = [list(map(str, r)) for r in cur.fetchall()]
        blocks.append({"query": q.strip()[:120] + "...", "columns": cols, "rows": data})
    out[f.name] = blocks

(ROOT/"results.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
for name, blocks in out.items():
    print(f"== {name}")
    for b in blocks:
        print("  cols:", b["columns"])
        for r in b["rows"][:12]:
            print("   ", r)
